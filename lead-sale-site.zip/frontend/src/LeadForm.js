import React, { useEffect, useState } from 'react';
import axios from 'axios';

function LeadForm() {
  const [reviews, setReviews] = useState([]);

  useEffect(() => {
    axios.get('https://lead-sale-backend.onrender.com/api/reviews')
      .then(res => setReviews(res.data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div className="container">
      <h2>Buy Facebook Marketplace Leads</h2>
      <p>1 lead = 0.40 Taka | Minimum 20, Maximum 100 leads per order</p>
      <p>Email: leadgenerationpk57@gmail.com</p>
      <p>Payment: Binance ID 557171983</p>

      <h3>Customer Reviews</h3>
      {reviews.map((review, i) => (
        <div key={i} className="review">
          <strong>{review.name}:</strong> {review.message}
        </div>
      ))}
    </div>
  );
}

export default LeadForm;
