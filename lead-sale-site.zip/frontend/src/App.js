import React from 'react';
import LeadForm from './LeadForm';

function App() {
  return (
    <div className="App">
      <LeadForm />
    </div>
  );
}

export default App;
