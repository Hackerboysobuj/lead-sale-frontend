const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());

const reviews = [
  { name: "John D. (USA)", message: "Excellent leads, got instant results!" },
  { name: "Mizan R. (BD)", message: "খুব ভালো সার্ভিস। আমি ৫০টা লিড নিয়েছি।" },
  { name: "Emily S. (USA)", message: "Best lead service I’ve ever used!" },
  { name: "Sajib A. (BD)", message: "দারুণ কাজ করছে, আবার নিবো।" },
  { name: "William T. (USA)", message: "Perfect for my Facebook ads." },
  { name: "Nusrat H. (BD)", message: "আমি সেল পেয়েছি প্রথম দিনেই!" },
  { name: "Jason L. (USA)", message: "Trustworthy and quick delivery." },
  { name: "Habib B. (BD)", message: "খুবই হেল্পফুল সার্ভিস।" },
  { name: "Kelly R. (USA)", message: "These guys deliver exactly what they promise." },
  { name: "Tania K. (BD)", message: "Real leads, very satisfied!" }
];

app.get('/api/reviews', (req, res) => {
  res.json(reviews);
});

app.listen(5000, () => console.log('Server running on port 5000'));
